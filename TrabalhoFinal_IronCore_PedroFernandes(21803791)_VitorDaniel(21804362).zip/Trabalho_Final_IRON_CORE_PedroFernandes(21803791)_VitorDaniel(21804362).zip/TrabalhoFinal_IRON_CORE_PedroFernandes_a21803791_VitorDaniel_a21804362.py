import pygame
pygame.init()
import sys, random, math
from pygame.locals import*

# TÍTULO DO JOGO
pygame.display.set_caption("IRON CORE")

# SOUNDTRACK
musica = ('Soundtrack_1.mp3')
pygame.mixer.init()
pygame.mixer.music.load(musica)
pygame.mixer.music.play()
pygame.event.wait()

# DEFINIÇAO DA JANELA DE JOGO
janela = pygame.display.set_mode((640, 448))
larguraJanela = 640
alturaJanela = 448

# TEXTO PARA INDICAR AS RONDAS E A MUSICA
texto = pygame.font.SysFont('Comic Sans MS', 24)
textoM = pygame.font.SysFont('Comic Sans MS', 15)
textoMusica = textoM.render('Musica feita por: "deleted_user_6988258" ', False, (250, 250, 250))
textoBM = texto.render('B', False, (137, 207, 240))
textoC = texto.render('C', False, (250, 0, 0))
# IMAGENS__________________________________________________________________________________________________________________________________________________________________________
# 640x448
entrada = pygame.image.load("SplashScreen.png")
vitoriaScreen = pygame.image.load("Victory.png")
derrotaScreen = pygame.image.load("GameOver.png")
# Bordas do mapa = 32:
mapa = pygame.image.load("Mapa.png")
    #448h/640w
bordMapas = 32
# 64x64:
alpha = pygame.image.load("Protagonista.png").convert_alpha(janela)
    #58h/48w
alphaPowerUp = pygame.image.load("hero_powerUp.png").convert_alpha()
    #64h/62w
cobaia = pygame.image.load("Inimigo 1.png").convert_alpha()
    #49h/41w
guarda = pygame.image.load("Inimigo 2.png").convert_alpha()
    #61h/63w
omega = pygame.image.load("Vilao.png").convert_alpha()
    #62h/49w
#caixa = pygame.image.load("Caixa.png")
# 32x32:
projetil = pygame.image.load("Ataque(prot.).png").convert_alpha()
projetilInim = pygame.image.load("Ataque(prot.)inimigo.png").convert_alpha()
    #26h/26w
powerUP = pygame.image.load("Power_Up.png").convert_alpha()
    #31h/31w

# CLASSES___________________________________________________________________________________________________________________________________________________________________________

# CLASSE JOGADOR

class alphaJ():
    def __init__(self):
        self.x = 64
        self.y = 224
        self.altura = 58
        self.largura = 48
        self.velocidade = 8
        self.cara = alpha
        self.vida = 5
        self.derrota = False
        self.babyMode = False
        self.iniciar = False
        self.continuar = True

# CLASSE INIMIGOS
class inimigos():
    def __init__(self):
        self.tamanho = 64
        # INIMIGO 1, movimento regular
        self.inimigo1V = 2
        self.inimigo1V_Save = 2
        self.velocidade1 = 5
        self.balaVel1 = bala.velocidade - 2
        self.direçao1x = 1
        self.direçao1y = 1
        self.inimigo1x = random.randint(larguraJanela/2 + self.tamanho/2, larguraJanela - bordMapas - self.tamanho)
        self.inimigo1y = random.randint(bordMapas + self.tamanho, alturaJanela - bordMapas - self.tamanho)
        self.inimigo1Actv = False
        self.bala1Atirada = False
        self.bala1Colisao = False
        self.bala1x = self.inimigo1x
        self.bala1y = self.inimigo1y
        
        # INIMIGO 2, segue o y do jogador
        self.inimigo2V = 2
        self.inimigo2V_Save = 2
        self.velocidade2 = jogador.velocidade
        self.balaVel2 = bala.velocidade
        self.inimigo2x = random.randint(larguraJanela/2 + self.tamanho/2, larguraJanela - bordMapas - self.tamanho)
        self.inimigo2y = random.randint(bordMapas + self.tamanho, alturaJanela - bordMapas - self.tamanho)
        self.inimigo2Actv = False
        self.bala2Atirada = False
        self.bala2Colisao = False
        self.bala2x = self.inimigo2x
        self.bala2y = self.inimigo2y

        # INIMIGO 3, segue o y do jogador e teleporta-se
        self.inimigo3V = 5
        self.inimigo3V_Save = 5
        self.velocidade3 = jogador.velocidade - 2
        self.direçao3x = 1
        self.inimigo3x = random.randint(larguraJanela/2 + self.tamanho/2, larguraJanela - bordMapas - self.tamanho)
        self.inimigo3y = random.randint(bordMapas + self.tamanho, alturaJanela - bordMapas - self.tamanho)
        self.inimigo3Actv = False
        self.balaVelOhm = bala.velocidade + 7
        self.bala3Atirada = False
        self.bala3Colisao = False
        self.bala3x = self.inimigo3x
        self.bala3y = self.inimigo3y
        self.cargaTeleport = 0
        self.cargaMax = 100

    def movimentoInim(self, larguraJanela, alturaJanela, bordMapas):
        # PRIMEIRA UNIDADE (COBAIA)
        if self.inimigo1Actv and self.inimigo1V > 0:
            # MOVIMENTO
            if self.inimigo1x <= larguraJanela/2:
                self.direçao1x = 1
                
            if self.inimigo1x >= larguraJanela - bordMapas - self.tamanho:
                self.direçao1x = -1

            if self.inimigo1y <= bordMapas:
                self.direçao1y = 1

            if self.inimigo1y >= alturaJanela - bordMapas - self.tamanho:
                self.direçao1y = -1

            # BALA
            if not self.bala1Atirada:
                self.bala1x = self.inimigo1x
                self.bala1y = self.inimigo1y
                self.bala1Atirada = True
                self.bala1Colisao = False
                
            if self.bala1Atirada and not self.bala1Colisao:
                self.bala1x -= self.balaVel1
                janela.blit(bala.tiroInim, (self.bala1x, self.bala1y))

            if self.bala1x < bordMapas + bala.raio:
                self.bala1x = self.inimigo1x
                self.bala1y = self.inimigo1y
                self.Bala1Atirada = False
                self.Bala1Colisao = False

            self.inimigo1x = self.inimigo1x + self.velocidade1*self.direçao1x
            self.inimigo1y = self.inimigo1y + self.velocidade1*self.direçao1y
            janela.blit(cobaia, (self.inimigo1x, self.inimigo1y))
                
        # SEGUNDA UNIDADE (SEGURANÇA)
        if self.inimigo2Actv and self.inimigo2V > 0:
            # MOVIMENTO
            if self.inimigo2y < jogador.y:
                self.inimigo2y += self.velocidade2
                
            if self.inimigo2y > jogador.y:
                self.inimigo2y -= self.velocidade2

            # BALA
            if not self.bala2Atirada:
                self.bala2x = self.inimigo2x
                self.bala2y = self.inimigo2y
                self.bala2Atirada = True
                self.bala2Colisao = False
                
            if self.bala2Atirada and not self.bala2Colisao:
                self.bala2x -= self.balaVel2
                janela.blit(bala.tiroInim, (self.bala2x, self.bala2y))

            if self.bala2x < bordMapas + bala.raio:
                self.bala2x = self.inimigo2x
                self.bala2y = self.inimigo2y
                self.Bala2Atirada = False
                self.Bala2Colisao = False 

            janela.blit(guarda, (self.inimigo2x, self.inimigo2y))

        # TERCEIRA UNIDADE (OMEGA)
        if self.inimigo3Actv and self.inimigo3V > 0:
            if self.inimigo3x <= larguraJanela/2 + self.tamanho/2:
                self.direçao3x = 1
                
            if self.inimigo3x >= larguraJanela - bordMapas - self.tamanho/2:
                self.direçao3x = -1

            if self.inimigo3y < jogador.y:
                self.inimigo3y += self.velocidade3
                
            if self.inimigo3y > jogador.y:
                self.inimigo3y -= self.velocidade3

            self.inimigo3x = self.inimigo3x + self.velocidade3*self.direçao3x

            # BALA
            if not self.bala3Atirada:
                self.bala3x = self.inimigo3x
                self.bala3y = self.inimigo3y
                self.bala3Atirada = True
                self.bala3Colisao = False
                
            if self.bala3Atirada and not self.bala2Colisao:
                self.bala3x -= self.balaVelOhm
                janela.blit(bala.tiroInim, (self.bala3x, self.bala3y))

            if self.bala3x < bordMapas + bala.raio:
                self.bala3x = self.inimigo3x
                self.bala3y = self.inimigo3y
                self.Bala3Atirada = False
                self.Bala3Colisao = False

            janela.blit(omega, (self.inimigo3x, self.inimigo3y))


# CLASSE PROJETEIS
class tiros():
    def __init__(self):
        self.x = jogador.x + jogador.largura/2
        self.y = jogador.y + jogador.altura/2
        self.raio = 11
        self.velocidade = 10
        self.tiro = projetil
        self.tiroInim = projetilInim
        self.disparar = False
        self.direçao = 0
        self.colisao = False
        self.upgrade = False
        self.recuperada = True

    def dispararBala(self, alturaJanela, larguraJanela, bordMapas):

        self.colisao = False            

        if not self.colisao:
            #pygame.time.delay(50)

            if self.direçao == 1:
                if self.y > self.velocidade + bordMapas:
                    self.y -= self.velocidade
                else:
                    self.colisao = True
                    self.disparar = False
    
            elif self.direçao == 2:
                if self.x > self.velocidade + bordMapas:
                    self.x -= self.velocidade
                else:
                    self.colisao = True
                    self.disparar = False

            elif self.direçao == 3:
                if self.y < alturaJanela - bordMapas - self.velocidade:
                    self.y += self.velocidade
                else:
                    self.colisao = True
                    self.disparar = False

            elif self.direçao == 4:
                if self.x < larguraJanela - bordMapas - self.velocidade:
                    self.x += self.velocidade
                else:
                    self.colisao = True
                    self.disparar = False

# CLASSE POWERUPS
class upgrade():
    def __init__(self):
        self.tamanho = 32
        self.x = random.randint(bordMapas + self.tamanho, larguraJanela - bordMapas - self.tamanho)
        self.y = random.randint(bordMapas + self.tamanho, alturaJanela - bordMapas - self.tamanho)
        self.raio = self.tamanho/2
        self.apanhado = False
        self.disponivel = False
        self.existe = 0

# CLASSE RONDAS
class rondas():
    def __init__(self):
        self.ronda = 1
        self.obstáculo = False
        self.ronda1Init = False
        self.ronda1Terminada = False
        self.ronda2Init = False
        self.ronda2Terminada = False
        self.ronda3Init = False
        self.ronda3Terminada = False

    def ronda1(self):
        chip.existe = random.randint(0, 2)
        if not chip.apanhado and chip.existe < 1 :
            chip.disponivel = True
        jogador.x = 64
        jogador.y = 224
        viloes.inimigo1Actv = True
        viloes.inimigo1V = viloes.inimigo1V_Save
        self.ronda1Init = True

    def ronda2(self):
        chip.existe = random.randint(0, 2)
        if not chip.apanhado and chip.existe < 1 :
            chip.disponivel = True
        jogador.x = 64
        jogador.y = 224
        viloes.inimigo1Actv = True
        viloes.inimigo1V = viloes.inimigo1V_Save
        viloes.inimigo1x = random.randint(larguraJanela/2 + viloes.tamanho/2, larguraJanela - bordMapas - viloes.tamanho)
        viloes.inimigo1y = random.randint(bordMapas + viloes.tamanho, alturaJanela - bordMapas - viloes.tamanho)
        viloes.inimigo2Actv = True
        viloes.inimigo2V = viloes.inimigo2V_Save
        self.ronda2Init = True

    def ronda3(self):
        chip.existe = random.randint(0, 1)
        if not chip.apanhado and chip.existe < 1 :
            chip.disponivel = True
        jogador.x = 64
        jogador.y = 224
        viloes.inimigo1Actv = True
        viloes.inimigo1V = viloes.inimigo1V_Save
        viloes.inimigo1x = random.randint(larguraJanela/2 + viloes.tamanho/2, larguraJanela - bordMapas - viloes.tamanho)
        viloes.inimigo1y = random.randint(bordMapas + viloes.tamanho, alturaJanela - bordMapas - viloes.tamanho)
        viloes.inimigo2Actv = True
        viloes.inimigo2V = viloes.inimigo2V_Save
        viloes.inimigo2x = random.randint(larguraJanela/2 + viloes.tamanho/2, larguraJanela - bordMapas - viloes.tamanho)
        viloes.inimigo2y = random.randint(bordMapas + viloes.tamanho, alturaJanela - bordMapas - viloes.tamanho)
        viloes.inimigo3Actv = True
        viloes.inimigo3V = viloes.inimigo3V_Save
        self.ronda3Init = True



    
# CHAMAR CLASSES___________________________________________________________________________________________________________________________________________________________________
jogador = alphaJ()
bala = tiros()
chip = upgrade()
viloes = inimigos()
niveis = rondas()
# RECRIAR A JANELA__________________________________________________________________________________________________________________________________________________________________
def refazJanela():
    janela.blit(mapa, (0, 0))
    janela.blit(textoMusica, (310, 425))
    if jogador.babyMode:
        janela.blit(textoBM, (11, 52))

    # BATERIA
    if jogador.vida >= 0:
        pygame.draw.rect(janela, [0, 150, 0], [289, 5, 62, 22], 3)
        pygame.draw.rect(janela, [0, 150, 0], [301, 5, 12, 22], 3)
        pygame.draw.rect(janela, [0, 150, 0], [313, 5, 12, 22], 3)
        pygame.draw.rect(janela, [0, 150, 0], [325, 5, 12, 22], 3)
        pygame.draw.rect(janela, [0, 150, 0], [337, 5, 12, 22], 3)        
        if jogador.vida >= 1:
            pygame.draw.rect(janela, [0, 250, 0], [291, 7, 10, 19], 0)
            if jogador.vida >= 2:
                pygame.draw.rect(janela, [0, 250, 0], [303, 7, 10, 19], 0)
                if jogador.vida >= 3:
                    pygame.draw.rect(janela, [0, 250, 0], [315, 7, 10, 19], 0)
                    if jogador.vida >= 4:
                        pygame.draw.rect(janela, [0, 250, 0], [327, 7, 10, 19], 0)
                        if jogador.vida >= 5:
                            pygame.draw.rect(janela, [0, 250, 0], [339, 7, 10, 19], 0)



            
##    # CHAO DE METAL (SE FOR PARA NAO APARECER, SIMPLESMENTE METE TUDO EM COMENTARIO, NAO APAGUES PFV, DA MUITO TRABALHO)
##    janela.blit(caixaRect, (32, 32))
##    janela.blit(caixaRect, (32 + 128*1, 32))
##    janela.blit(caixaRect, (32 + 128*2, 32))
##    janela.blit(caixaRect, (32 + 128*3, 32))
##    janela.blit(caixa, (32 + 128*4, 32))
##    
##    janela.blit(caixaRect, (32, 32 + 64*1))
##    janela.blit(caixaRect, (32 + 128*1, 32 + 64*1))
##    janela.blit(caixaRect, (32 + 128*2, 32 + 64*1))
##    janela.blit(caixaRect, (32 + 128*3, 32 + 64*1))
##    janela.blit(caixa, (32 + 128*4, 32 + 64*1))
##    
##    janela.blit(caixaRect, (32, 32 + 64*2))
##    janela.blit(caixaRect, (32 + 128*1, 32 + 64*2))
##    janela.blit(caixaRect, (32 + 128*2, 32 + 64*2))
##    janela.blit(caixaRect, (32 + 128*3, 32 + 64*2))
##    janela.blit(caixa, (32 + 128*4, 32 + 64*2))
##    
##    janela.blit(caixaRect, (32, 32 + 64*3))
##    janela.blit(caixaRect, (32 + 128*1, 32 + 64*3))
##    janela.blit(caixaRect, (32 + 128*2, 32 + 64*3))
##    janela.blit(caixaRect, (32 + 128*3, 32 + 64*3))
##    janela.blit(caixa, (32 + 128*4, 32 + 64*3))
##    
##    janela.blit(caixaRect, (32, 32 + 64*4))
##    janela.blit(caixaRect, (32 + 128*1, 32 + 64*4))
##    janela.blit(caixaRect, (32 + 128*2, 32 + 64*4))
##    janela.blit(caixaRect, (32 + 128*3, 32 + 64*4))
##    janela.blit(caixa, (32 + 128*4, 32 + 64*4))
##    
##    janela.blit(caixaRect, (32, 32 + 64*5))
##    janela.blit(caixaRect, (32 + 128*1, 32 + 64*5))
##    janela.blit(caixaRect, (32 + 128*2, 32 + 64*5))
##    janela.blit(caixaRect, (32 + 128*3, 32 + 64*5))
##    janela.blit(caixa, (32 + 128*4, 32 + 64*5))
    
    # CHIP E PERSONAGEM
    if chip.disponivel and not chip.apanhado:
        janela.blit(powerUP, (chip.x, chip.y))
    if chip.apanhado == True:
        janela.blit(textoC, (11, 82))
        janela.blit(alphaPowerUp, (jogador.x, jogador.y))
        jogador.altura = 64
        jogador.largura = 62
        jogador.velocidade = 10
    else:
        janela.blit(jogador.cara, (jogador.x, jogador.y))
    # Bala acompanha jogador (nao dispara)
    if not bala.disparar or bala.colisao:
        bala.x = jogador.x + jogador.largura/2 - bala.raio
        bala.y = jogador.y + jogador.altura/2 - bala.raio
        bala.recuperada = True
        bala.colisao = False
        # (para ver se a bala regressa ao jogador): janela.blit(bala.tiro, (bala.x, bala.y))

    # INICIA RONDAS
    if niveis.ronda == 1 and not niveis.ronda1Init:
        niveis.ronda1()
    if niveis.ronda == 1 and viloes.inimigo1V <= 0:
        niveis.ronda = 2

    if niveis.ronda == 2 and not niveis.ronda2Init:
        niveis.ronda2()
    if niveis.ronda == 2 and viloes.inimigo1V <= 0 and viloes.inimigo2V <= 0:
        niveis.ronda = 3

    if niveis.ronda == 3 and not niveis.ronda3Init:
        niveis.ronda3()
    if niveis.ronda == 3 and viloes.inimigo1V <= 0 and viloes.inimigo2V <= 0 and viloes.inimigo3V <= 0:
         niveis.ronda = 4
         jogador.continuar = False

    viloes.movimentoInim(larguraJanela, alturaJanela, bordMapas)
    
    if bala.disparar and not bala.colisao:
        bala.dispararBala(alturaJanela, larguraJanela, bordMapas)
        janela.blit(projetil, (bala.x, bala.y))

    # TEXTO
    if niveis.ronda < 4: 
        textoDasRondas = texto.render('Ronda: ' + str(niveis.ronda), False, (200, 0, 0))
        janela.blit(textoDasRondas, (32, 0))
    
    # UPDATE    
    pygame.display.update()

# CORPO DO CODIGO_______________________________________________________________________________________________

while jogador.continuar:
    pygame.time.delay(30)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            jogador.continuar = False

    teclas = pygame.key.get_pressed()

    # SPLASH-SCREEN
    if jogador.iniciar == False:
        janela.blit(entrada, (0, 0))
        pygame.display.update()
        if teclas[pygame.K_x]:
            jogador.iniciar = True

    if jogador.iniciar == True:

        # CHEAT-CHEAT PARA USAR O CHIP (C)
        if teclas[pygame.K_c]:
           bala.upgrade = True
           chip.apanhado = True

        # CHEAT-CHEAT PARA JOGAR EM "BABY_MODE" (B)
        if teclas[pygame.K_b]:
            jogador.babyMode = True

        # ANDAR
        if teclas[pygame.K_LEFT] and jogador.x > bordMapas:
            jogador.x -= jogador.velocidade
              
        if teclas[pygame.K_RIGHT] and jogador.x < larguraJanela - bordMapas - jogador.largura:
            jogador.x += jogador.velocidade

        if teclas[pygame.K_UP] and jogador.y > bordMapas:
            jogador.y -= jogador.velocidade

        if teclas[pygame.K_DOWN] and jogador.y < alturaJanela - bordMapas - jogador.altura*1.5:
            jogador.y += jogador.velocidade

        # DISPARAR
        if teclas[pygame.K_w] and bala.recuperada or teclas[pygame.K_w] and bala.upgrade:
            bala.disparar = True
            bala.direçao = 1
            bala.recuperada = False

        if teclas[pygame.K_a] and bala.recuperada or teclas[pygame.K_a] and bala.upgrade:
            bala.disparar = True
            bala.direçao = 2
            bala.recuperada = False

        if teclas[pygame.K_s] and bala.recuperada or teclas[pygame.K_s] and bala.upgrade:
            bala.disparar = True
            bala.direçao = 3
            bala.recuperada = False

        if teclas[pygame.K_d] and bala.recuperada or teclas[pygame.K_d] and bala.upgrade:
            bala.disparar = True
            bala.direçao = 4
            bala.recuperada = False

        # APANHAR CHIP
        if (chip.x < jogador.x + jogador.largura/2 < chip.x + chip.tamanho and chip.y < jogador.y + jogador.largura/2 < chip.y + chip.tamanho) and chip.disponivel:
            chip.disponivel = False
            chip.apanhado = True
            bala.upgrade = True

        # JOGADOR ACERTA EM INIMIGOS (E MORREM)
        if viloes.inimigo1x < bala.x + bala.raio < viloes.inimigo1x + viloes.tamanho and viloes.inimigo1y < bala.y + bala.raio < viloes.inimigo1y + viloes.tamanho and viloes.inimigo1Actv and viloes.inimigo1V > 0 and bala.disparar:
            bala.colisao = True
            bala.disparar = False
            viloes.inimigo1V -= 1
            if viloes.inimigo1V <= 0:
                viloes.inimigo1Actv = False

        if viloes.inimigo2x < bala.x + bala.raio < viloes.inimigo2x + viloes.tamanho and viloes.inimigo2y < bala.y + bala.raio < viloes.inimigo2y + viloes.tamanho and viloes.inimigo2Actv and viloes.inimigo2V > 0 and bala.disparar:
            bala.colisao = True
            bala.disparar = False
            viloes.inimigo2V -= 1
            if viloes.inimigo2V <= 0:
                viloes.inimigo2Actv = False

        if viloes.inimigo3x < bala.x + bala.raio < viloes.inimigo3x + viloes.tamanho and viloes.inimigo3y < bala.y + bala.raio < viloes.inimigo3y + viloes.tamanho and viloes.inimigo3Actv and viloes.inimigo3V > 0 and bala.disparar:
            bala.colisao = True
            bala.disparar = False
            viloes.inimigo3V -= 1
            if viloes.inimigo3V <= 0:
                viloes.inimigo3Actv = False

        if not jogador.babyMode:
            # INIMIGOS ACERTAM EM JOGADOR (E MORRE)
            if (jogador.x < viloes.bala1x + bala.raio < jogador.x + jogador.largura and jogador.y < viloes.bala1y + bala.raio < jogador.y + jogador.altura and viloes.bala1Atirada) and jogador.vida > 0:
                jogador.vida -= 1
                viloes.bala1Atirada = False
                if jogador.vida <= 0:
                    jogador.derrota = True
                    jogador.continuar = False
                    
            if (jogador.x < viloes.bala2x + bala.raio < jogador.x + jogador.largura and jogador.y < viloes.bala2y + bala.raio < jogador.y + jogador.altura and viloes.bala2Atirada) and jogador.vida > 0:
                jogador.vida -= 1
                viloes.bala2Atirada = False
                if jogador.vida <= 0:
                    jogador.derrota = True
                    jogador.continuar = False

            if (jogador.x < viloes.bala3x + bala.raio < jogador.x + jogador.largura and jogador.y < viloes.bala3y + bala.raio < jogador.y + jogador.altura and viloes.bala3Atirada) and jogador.vida > 0:
                jogador.vida -= 1
                viloes.bala3Atirada = False
                if jogador.vida <= 0:
                    jogador.derrota = True
                    jogador.continuar = False
                
        if jogador.continuar:
            refazJanela()

# ECRA DE VITORIA
if niveis.ronda > 3:
    janela.blit(vitoriaScreen, (0, 0))
    pygame.display.update()
    pygame.time.delay(5000)

# ECRA DE DERROTA
if jogador.vida <= 0 and jogador.derrota:
    janela.blit(derrotaScreen, (0, 0))
    pygame.display.update()
    pygame.time.delay(5000)

# FIM DO JOGO    
pygame.quit()
